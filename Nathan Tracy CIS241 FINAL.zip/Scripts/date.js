/* date.js */
setTimeout(function () {
    document.getElementById('date').value = new Date();
}, 1000);